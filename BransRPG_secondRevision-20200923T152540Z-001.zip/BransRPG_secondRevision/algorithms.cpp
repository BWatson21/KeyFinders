#include <iostream>
#include <ctime>
#include <cmath>
#include <vector>
#include "algorithms.h"

using namespace std;

int xRandVal(int previousX, int keyX){
    int newX = 10;

    //srand(time(0));

    while ((newX == 10) || (newX == previousX) || (newX == keyX)){
        newX = (rand() % 20);
    }

    return newX;
}

int yRandVal(int previousY, int keyY, int X){
    int newY = 10;

    //srand(time(0));

    while ((newY == 10) || (newY == previousY) || (newY == keyY) || (newY == X)){
        newY = (rand() % 20);
    }

    return newY;
}

void EnemyXYPos(int &x, int &y, int keyX, int keyY){
    //srand(time(0));

    int newX = 10;
    int newY = 10;

    while (((newX == 10) && (newY == 10)) || ((newX == keyX) && (newY == keyY))){
        newX = (rand() % 20);
        newY = (rand() % 20);
    }

    x = newX;
    y = newY;
}

void EnemyXYPos(int &x, int &y, vector<int> &vectX, vector<int> &vectY, int keyX, int keyY){
    //srand(time(0));

    int newX = 10;
    int newY = 10;

    bool goodVals = false;

    while ((((newX == 10) && (newY == 10)) || ((newX == keyX) && (newY == keyY)) || ((newX == x) && (newY == y))) && (goodVals == false)){
        newX = (rand() % 20);
        newY = (rand() % 20);

        for (unsigned int i = 0; i < vectX.size(); i++){
            for (unsigned int j = 0; j < vectY.size(); j++){
                if ((vectY[j] == newY) && (vectX[i] == newX)){
                    goodVals = false;
                    continue;
                }
                else if ((vectY[j] != newY) && (vectX[i] != newX)){
                    goodVals = true;
                    break;
                }

            }
        }
    }

    x = newX;
    y = newY;

    vectX.push_back(x);
    vectY.push_back(y);
}

bool EnemyAttack(int enAgility, bool enDefend){
    int attackPotential = enAgility / 10; //drops it into signle digit range 1-5

    int attackProb = (rand() % 6) + (rand() % attackPotential); //the probablity is based on agility

    //attackProb = attackProb % 2;

    bool attack = false;

    if (attackProb < 5){
        attack = false;
    }
    else if (attackProb >= 5){
        attack = true;
    }

    if (enDefend == true){
        attack = false;
    }

    return attack;
}
bool EnemyDefend(int enAgility){
    int defPotential = enAgility / 10; //drops it into signle digit range 1-5

    int defProb = (rand() % 6) + (rand() % defPotential); //the probablity is based on agility

    //attackProb = attackProb % 2;

    bool defend = false;

    if (defProb < 5){
        defend = false;
    }
    else if (defProb >= 5){
        defend = true;
    }

    return defend;
}

bool UserDefend(int userAgility){
    int defPotential = userAgility / 10; //drops it into signle digit range 1-5

    int defProb = (rand() % 6) + (rand() % defPotential); //the probablity is based on agility

    //attackProb = attackProb % 2;

    bool defend = false;

    if (defProb < 3){
        defend = false;
    }
    else if (defProb >= 3){
        defend = true;
    }

    return defend;
}

