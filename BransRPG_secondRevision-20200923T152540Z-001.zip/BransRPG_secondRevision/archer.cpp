#include <iostream>
#include "archer.h"

using namespace std;

Archer::Archer(){
    setName("");
    setUsername("");
    setHealth(0);
    setAttack(0);
    setRange(0);
    setAgility(0);
}
Archer::Archer(std::string user){
    setName("Archer");
    setUsername(user);
    setHealth(80);
    setAttack(70);
    setRange(4);
    setAgility(40);
    chosenCharacter();
}

Archer::~Archer(){

}

void Archer::chosenCharacter(){
    cout << "You have chosen Archer as your key finder!" << endl;
}
