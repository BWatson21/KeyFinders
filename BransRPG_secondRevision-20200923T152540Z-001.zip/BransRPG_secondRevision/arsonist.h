#ifndef ARSONIST_H
#define ARSONIST_H

#include <iostream>
#include "entity.h"

using namespace std;

class Arsonist: public Entity{
private:

public:
    Arsonist();
    ~Arsonist();
};

#endif // ARSONIST_H
