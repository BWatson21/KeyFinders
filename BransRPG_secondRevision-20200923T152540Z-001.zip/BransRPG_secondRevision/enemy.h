#ifndef ENEMY_H
#define ENEMY_H

#include <iostream>

using namespace std;

class Enemy{
private:
    std::string nameEnemy;
    int health;
    int attack;
    int range;
    int agility;
    int posX;
    int posY;
public:
    Enemy();

    void setNameEnemy(string nam);
    std::string getNameEnemy();

    void setHealthEnemy(int h);
    int getHealthEnemy();

    void setAttackEnemy(int att);
    int getAttackEnemy();

    void setRangeEnemy(int r);
    int getRangeEnemy();

    void setAgilityEnemy(int agi);
    int getAgilityEnemy();

    void setPosXEnemy(int x);
    int getPosXEnemy();

    void setPosYEnemy(int y);
    int getPosYEnemy();
};

#endif // ENEMY_H
