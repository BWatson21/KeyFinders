#include <iostream>
#include "entity.h"

using namespace std;

Entity::Entity(){
    setName("");
    setUsername("");
    setHealth(0);
    setAttack(0);
    setRange(0);
    setAgility(0);
}
Entity::Entity(std::string user){
    name = "Mr.Nobody";
    username = user;
    health = 10;
    attack = 5;
    range = 1;
    agility = 10;
    chosenCharacter();
}
Entity::Entity(std::string entNam, std::string user, int h, int att, int r, int agi){
    name = entNam;
    username = user;
    health = h;
    attack = att;
    range = r;
    agility = agi;
}

Entity::~Entity(){

}

void Entity::setName(std::string nam){
    name = nam;
}
string Entity::getName(){
    return name;
}

void Entity::setUsername(std::string user){
    username = user;
}
string Entity::getUsername(){
    return username;
}

void Entity::setHealth(int h){
    health = h;
}
int Entity::getHealth(){
    return health;
}

void Entity::setAttack(int att){
    attack = att;
}
int Entity::getAttack(){
    return attack;
}

void Entity::setRange(int r){
    range = r;
}
int Entity::getRange(){
    return range;
}

void Entity::setAgility(int agi){
    agility = agi;
}
int Entity::getAgility(){
    return agility;
}

void Entity::setPosX(int x){
    posX = x;
}
int Entity::getPosX(){
    return posX;
}

void Entity::setPosY(int y){
    posY = y;
}
int Entity::getPosY(){
    return posY;
}

void Entity::chosenCharacter(){
    cout << "You have chosen Mr.Nobody as your key finder!" << endl;
}
