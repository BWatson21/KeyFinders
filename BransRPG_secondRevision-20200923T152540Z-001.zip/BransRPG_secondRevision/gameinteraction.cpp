#include <iostream>
#include "gameinteraction.h"

using namespace std;

void playerControls(){
    cout << "------------Player Controls-----------" << endl << endl;
    cout << "When not in battle: " << endl;
    cout << "W or w = move forawrd" << endl;
    cout << "A or a = move left" << endl;
    cout << "S or s = move backward" << endl;
    cout << "D or d = move right" << endl;
    cout << "E or e = use syringes" << endl << endl;
    cout << "When in battle: " << endl;
    cout << "R or r = choose to attack" << endl;
    cout << "C or c = choose to defend" << endl;
    cout << "E or e = use syringes" << endl << endl;
    cout << "--------------------------------------" << endl << endl;

    for (int i = 0; i < 6; i++){
        cout << "\n";
    }

    pressX();
}

void showEnemyFacts(int h, int a, int r, int ag){
    cout << "--------------Enemy Stats-------------" << endl << endl;
    cout << "Health: " << h << endl;
    cout << "Attack: " << a << endl;
    cout << "Range: " << r << endl;
    cout << "Speed: " << ag << endl << endl;
    cout << "--------------------------------------" << endl << endl;
}

void clear(){
    for (int i = 0; i < 100; i++){
        cout << "\n";
    }
}

void pressX(){
    cout << "Press x to continue: ";
    char press;
    cin >> press;

    if (press != 'x'){
        cout << "Invalid Selection." << endl;
        pressX();
    }
    else {
        clear();
    }
}

void dungeonIntro(){
    for (int i = 0; i < 12; i++){
        cout << "\n";
    }

    cout << "-----------------------------------------------------------------------" << endl;
    cout << "Welcome to Bran's RPG." << endl;
    cout << "It seems as though you have been kidnapped and locked in this dungeon." << endl;
    cout << "A key has been placed somewhere inside." << endl;
    cout << "This is your escape." << endl;
    cout << "But beware, as you are not alone in this dungeon." << endl;
    cout << "You might want to get looking before the person who took you gets back." << endl;
    cout << "-----------------------------------------------------------------------" << endl;

    for (int i = 0; i < 10; i++){
        cout << "\n";
    }

    pressX();
}

void showPlayerScore(int score){
    clear();
    cout << "--------------------------------------" << endl;
    cout << "Your final score is: " << score << endl;
    cout << "--------------------------------------" << endl;

    for(int i = 0; i < 10; i++){
        cout << "\n";
    }

    pressX();
}
