#include <iostream>
#include "giant.h"

using namespace std;

Giant::Giant(){
    setName("");
    setUsername("");
    setHealth(0);
    setAttack(0);
    setRange(0);
    setAgility(0);
}
Giant::Giant(std::string user){
    setName("Giant");
    setUsername(user);
    setHealth(200);
    setAttack(80);
    setRange(1);
    setAgility(20);
    chosenCharacter();
}

Giant::~Giant(){

}

void Giant::chosenCharacter(){
    cout << "You have chosen Giant as your key finder!" << endl;
}
