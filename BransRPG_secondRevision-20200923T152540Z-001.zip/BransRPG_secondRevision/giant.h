#ifndef GIANT_H
#define GIANT_H

#include <iostream>
#include "entity.h"
using namespace std;

class Giant: public Entity{
private:

public:
    Giant();
    Giant(std::string user);
    ~Giant();

    void chosenCharacter();
};

#endif // GIANT_H
