#ifndef GULAG_H
#define GULAG_H

#include <iostream>
#include "entity.h"

using namespace std;

class Gulag: public Entity{
private:

public:
    Gulag();
    ~Gulag();
};

#endif // GULAG_H
