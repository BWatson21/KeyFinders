#include <iostream>
#include "leaderboard.h"

using namespace std;

void Leaderboard::setPlayer(std::string p){
    this->player = p;
}
std::string Leaderboard::getPlayer(){
    return player;
}

void Leaderboard::setScore(long int s){
    score = s;
}
long int Leaderboard::getScore(){
    return score;
}


