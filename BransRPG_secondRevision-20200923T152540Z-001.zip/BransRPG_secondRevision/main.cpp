#include <iostream>
#include <cmath>
#include <ctime>
#include <vector>
#include <fstream>
#include <iomanip>
#include "entity.h"
#include "giant.h"
#include "archer.h"
#include "wizard.h"
#include "swordsman.h"
#include "player.h"
#include "cyclops.h"
#include "arsonist.h"
#include "gulag.h"
#include "psychomaniac.h"
#include "enemy.h"
#include "grid.h"
#include "algorithms.h"
#include "gameinteraction.h"
#include "leaderboard.h"

using namespace std;

int main()
{
    //leaderboard initialization
    ifstream lFile;
    lFile.open("leaderboard.txt");
    if (lFile.fail())
    {
        cout << "Unable to Access Leaderboard Records" << endl;
        exit(1);
    };//end if

    int numrecs = 0;
    lFile >> numrecs;

    Leaderboard* lArray[10];

    for (int i = 0; i < 10; i++){
        lArray[i] = new Leaderboard;
    }

    string playerName;
    long int playerScore;

    int i = 0;

    //fills array with file values

    while(lFile >> playerName >> playerScore){
        lArray[i]->setPlayer(playerName);
        lArray[i]->setScore(playerScore);

        i++;
    }

    lFile.close();

    //game active
    bool gameActive = true;

    //true random generation
    srand(time(0));

    //Grid initialization
    Grid grid[20][20];

    //grid x, y values initialization
    for (int i = 0; i < 20; i++) {
        for (int j = 0; j < 20; j++){
            grid[i][j].setGridX(i);
            grid[i][j].setGridY(j);
        }
    }

    //key initialization
    int keyX = xRandVal(0, 0);
    int keyY = yRandVal(0, 0, keyX);
    grid[keyX][keyY].setIs_Key(true);

    //enemy initialization script
    Cyclops* cEnemy = new Cyclops;
    std::string cName = cEnemy->getName();
    int cHealth = cEnemy->getHealth();
    int cAttack = cEnemy->getAttack();
    int cRange = cEnemy->getRange();
    int cAgility = cEnemy->getAgility();

    Arsonist* aEnemy = new Arsonist;
    std::string aName = aEnemy->getName();
    int aHealth = aEnemy->getHealth();
    int aAttack = aEnemy->getAttack();
    int aRange = aEnemy->getRange();
    int aAgility = aEnemy->getAgility();

    Psychomaniac* pEnemy = new Psychomaniac;
    std::string pName = pEnemy->getName();
    int pHealth = pEnemy->getHealth();
    int pAttack = pEnemy->getAttack();
    int pRange = pEnemy->getRange();
    int pAgility = pEnemy->getAgility();

    Gulag* gEnemy = new Gulag;
    std::string gName = gEnemy->getName();
    int gHealth = gEnemy->getHealth();
    int gAttack = gEnemy->getAttack();
    int gRange = gEnemy->getRange();
    int gAgility = gEnemy->getAgility();

    Enemy Enemies[30];

    vector<int> enemyXVals; //vector that holds all enemy x position data
    vector<int> enemyYVals; //vecotr that holds all enemy y position data

    int EnemyXVal = 0;
    int EnemyYVal = 0;

    EnemyXYPos(EnemyXVal, EnemyYVal, keyX, keyY);

    enemyXVals.push_back(EnemyXVal);
    enemyYVals.push_back(EnemyYVal);

    for (int i = 0; i < 30; i++) {
        if (i < 10){ //gulag initialization
            Enemies[i].setPosXEnemy(EnemyXVal);
            Enemies[i].setPosYEnemy(EnemyYVal);
            Enemies[i].setNameEnemy(gName);
            Enemies[i].setHealthEnemy(gHealth);
            Enemies[i].setAttackEnemy(gAttack);
            Enemies[i].setRangeEnemy(gRange);
            Enemies[i].setAgilityEnemy(gAgility);
            grid[EnemyXVal][EnemyYVal].setIs_Enemy(true);
            grid[EnemyXVal][EnemyYVal].setiVal(i);
            EnemyXYPos(EnemyXVal, EnemyYVal, enemyXVals, enemyYVals, keyX, keyY);
        }
        else if ((i >= 10) && (i < 18)){ //psychomaniac initialization
            Enemies[i].setPosXEnemy(EnemyXVal);
            Enemies[i].setPosYEnemy(EnemyYVal);
            Enemies[i].setNameEnemy(pName);
            Enemies[i].setHealthEnemy(pHealth);
            Enemies[i].setAttackEnemy(pAttack);
            Enemies[i].setRangeEnemy(pRange);
            Enemies[i].setAgilityEnemy(pAgility);
            grid[EnemyXVal][EnemyYVal].setIs_Enemy(true);
            grid[EnemyXVal][EnemyYVal].setiVal(i);
            EnemyXYPos(EnemyXVal, EnemyYVal, enemyXVals, enemyYVals, keyX, keyY);
        }
        else if ((i >= 18) && (i < 25)){ //arsonist initialization
            Enemies[i].setPosXEnemy(EnemyXVal);
            Enemies[i].setPosYEnemy(EnemyYVal);
            Enemies[i].setNameEnemy(aName);
            Enemies[i].setHealthEnemy(aHealth);
            Enemies[i].setAttackEnemy(aAttack);
            Enemies[i].setRangeEnemy(aRange);
            Enemies[i].setAgilityEnemy(aAgility);
            grid[EnemyXVal][EnemyYVal].setIs_Enemy(true);
            grid[EnemyXVal][EnemyYVal].setiVal(i);
            EnemyXYPos(EnemyXVal, EnemyYVal, enemyXVals, enemyYVals, keyX, keyY);
        }
        else if ((i >= 25) && (i < 30)){ //cyclops initialization
            Enemies[i].setPosXEnemy(EnemyXVal);
            Enemies[i].setPosYEnemy(EnemyYVal);
            Enemies[i].setNameEnemy(cName);
            Enemies[i].setHealthEnemy(cHealth);
            Enemies[i].setAttackEnemy(cAttack);
            Enemies[i].setRangeEnemy(cRange);
            Enemies[i].setAgilityEnemy(cAgility);
            grid[EnemyXVal][EnemyYVal].setIs_Enemy(true);
            grid[EnemyXVal][EnemyYVal].setiVal(i);
            EnemyXYPos(EnemyXVal, EnemyYVal, enemyXVals, enemyYVals, keyX, keyY);
        }
        else {
            break;
        }

    }

    //character possibilities initialization
    Giant gInitialize;
    Swordsman sInitialize;
    Archer aInitialize;
    Wizard wInitialize;
    Entity mrInitialize;

    //player character traits initialization
    int health, attack, range, agility, positionX, positionY;

    //game intro
    dungeonIntro();

    //player set up
    Player p;
    p.setUsername();
    string pNam = p.getUsername();
    p.selectCharacter();
    char PlayerCharacterSelection = p.getPlayerSel();

    //player character initialization
    switch(PlayerCharacterSelection){
    case '1':
        gInitialize = p.getGiant();
        health = gInitialize.getHealth();
        attack = gInitialize.getAttack();
        range = gInitialize.getRange();
        agility = gInitialize.getAgility();
        positionX = gInitialize.getPosX();
        positionY = gInitialize.getPosY();
        break;
    case '2':
        sInitialize = p.getSwordsman();
        health = sInitialize.getHealth();
        attack = sInitialize.getAttack();
        range = sInitialize.getRange();
        agility = sInitialize.getAgility();
        positionX = sInitialize.getPosX();
        positionY = sInitialize.getPosY();
        break;
    case '3':
        wInitialize = p.getWizard();
        health = wInitialize.getHealth();
        attack = wInitialize.getAttack();
        range = wInitialize.getRange();
        agility = wInitialize.getAgility();
        positionX = wInitialize.getPosX();
        positionY = wInitialize.getPosY();
        break;
    case '4':
        aInitialize = p.getArcher();
        health = aInitialize.getHealth();
        attack = aInitialize.getAttack();
        range = aInitialize.getRange();
        agility = aInitialize.getAgility();
        positionX = aInitialize.getPosX();
        positionY = aInitialize.getPosY();
        break;
    case 'k':
        mrInitialize = p.getEntity();
        health = mrInitialize.getHealth();
        attack = mrInitialize.getAttack();
        range = mrInitialize.getRange();
        agility = mrInitialize.getAgility();
        positionX = mrInitialize.getPosX();
        positionY = mrInitialize.getPosY();
        break;
    default:
        cout << "Internal Error." << endl;
        main();
        break;
    }

    //player grid initialization
    grid[positionX][positionY].setIs_Player(true);

    //Gameplay
    //player controls screen
    playerControls();

    //determines whether or not in battle mode
    bool Is_Battle = false;

    //health comparison for use with syringes
    int healthCompare = health;

    //player score
    int score = 0;

    while (gameActive == true){
        //spacing value
        int spacing;
        if (Is_Battle == false){
            spacing = 12;
        }
        else if (Is_Battle == true){
            spacing = 6;
        }
        //syringe count
        int syringeAmnt;

        //enemy traits
        int iVal;
        int enHealth;
        int enAttack;
        int enRange;
        int enAgility;

        //player choice prompt
        char playerControl;
        syringeAmnt = p.getSyringes();
        cout << "-----------------------------------" << endl;
        cout << "Player Health: " << health << endl; //displays player health
        cout << "Syringes remaining: " << syringeAmnt << endl; //displays number of syringes
        cout << "Player Pos: (" << positionX << ", " << positionY << ")" << endl;
        cout << "Player Score: " << score << endl;
        cout << "-----------------------------------" << endl;
        for (int i = 0; i < spacing; i++){
            cout << "\n";
        }
        cout << "What would you like to do: ";
        cin >> playerControl;

        clear();

        //determines player movement mechanics for non battle mode
        if (Is_Battle == false){
            grid[positionX][positionY].setIs_Player(false);
            p.playerMovement(playerControl, Is_Battle, positionX, positionY, attack, health, range, healthCompare, enHealth, enAttack, enRange, keyX, keyY, false, false, false);
            grid[positionX][positionY].setIs_Player(true);
        }

        //determines player movement mechanics for battle mode
        if (Is_Battle == true){
            bool Is_EnDefend = EnemyDefend(enAgility);
            bool Is_EnAttack = EnemyAttack(enAgility, Is_EnDefend);
            bool Is_UserDefend = UserDefend(agility);
            p.playerMovement(playerControl, Is_Battle, positionX, positionY, attack, health, range, healthCompare, enHealth, enAttack, enRange, keyX, keyY, Is_EnAttack, Is_EnDefend, Is_UserDefend);
            Enemies[iVal].setHealthEnemy(enHealth);
        }

        //checks to see if player landed on the same grid space as an enemy
        if(grid[positionX][positionY].getIs_Enemy() == true){
            Is_Battle = true;

            //clear();

            iVal = grid[positionX][positionY].getiVal();

            cout << "\nOh no a(n) " << Enemies[iVal].getNameEnemy() << "!" << endl;

            enHealth = Enemies[iVal].getHealthEnemy();
            enAttack = Enemies[iVal].getAttackEnemy();
            enRange = Enemies[iVal].getRangeEnemy();
            enAgility = Enemies[iVal].getAgilityEnemy();

            showEnemyFacts(enHealth, enAttack, enRange, enAgility);
        }

        if ((enHealth <= 0) && (Is_Battle == true)){
            grid[positionX][positionY].setIs_Enemy(false);
            Is_Battle = false;
            score += 100;

            clear();

            cout << "----------------------------------------" << endl;
            cout << "You have slain the enemy!" << endl;
            cout << "You are safe...for now." << endl;
            cout << "Who knows what may lurk down here." << endl;
            cout << "----------------------------------------" << endl;

            for (int i = 0; i < 10; i++){
                cout << "\n";
            }

            pressX();
        }

        if ((health <= 0) && (Is_Battle == true)){
            Is_Battle = false;
            enHealth = Enemies[iVal].getHealthEnemy();

            clear();

            cout << "----------------------------------------" << endl;
            cout << "You have been slain!" << endl;
            cout << "Next time you should be more wise." << endl;
            cout << "You now shall rot here in the dungeon." << endl;
            cout << "----------------------------------------" << endl;

            for (int i = 0; i < 10; i++){
                cout << "\n";
            }

            pressX();

            gameActive = false;
        }

        //checks to see if player is on the same grid space as key
        if (grid[positionX][positionY].getIs_Key() == true){
            score += 500;

            clear();

            cout << "------------------------------------------------------" << endl;
            cout << "Congratulations! You have found the key." << endl;
            cout << "You will now exit the dungeon." << endl;
            cout << "It is not wise to return, but I will not stop you..." << endl;
            cout << "------------------------------------------------------" << endl;

            for (int i = 0; i < 12; i++){
                cout << "\n";
            }

            pressX();

            gameActive = false;
        }
    }

    showPlayerScore(score);

    //updating leaderboard
    static long int repScore;
    static long int newRepScore;
    static string repNam;
    static string newRepNam;
    bool replaced = false;

    for (int i = 0; i < 10; i++){

        newRepScore = lArray[i]->getScore();
        newRepNam = lArray[i]->getPlayer();

        if (replaced == true){
            lArray[i]->setScore(repScore);
            lArray[i]->setPlayer(repNam);
        }
        else if ((score > lArray[i]->getScore()) && (replaced == false)){
            lArray[i]->setScore(score);
            lArray[i]->setPlayer(pNam);
            replaced = true;
        }

        repScore = newRepScore;
        repNam = newRepNam;
    }

    //display leaderboard
    clear();
    cout << "                      LeaderBoard                        " << endl;
    cout << "---------------------------------------------------------" << endl;
    cout << setw(21) << right << "|Player|" << setw(20) << right << "|Score|" << endl;
    for (int i = 0; i < 10; i++){
        cout << setw(20) << right << lArray[i]->getPlayer() << setw(20) << right << lArray[i]->getScore() << endl;
    }
    cout << "---------------------------------------------------------" << endl;
    for (int i = 0; i < 8; i++){
        cout << "\n";
    }
    pressX();

    //file update
    ofstream lUpdate;
    lUpdate.open("leaderboard.txt");
    if (lUpdate.fail())
    {
        cout << "Error Opening Outfile" << endl;
        exit(1);
    };//end if

    lUpdate << numrecs << endl << endl;

    for (int i = 0; i < numrecs; i++)
    {
        playerName = lArray[i]->getPlayer();
        playerScore = lArray[i]->getScore();

        lUpdate << setprecision(2) << setiosflags(ios::fixed | ios::showpoint);
        lUpdate << playerName << " " << playerScore << endl << endl;
    }//end for

    lUpdate.close();

    delete lArray[0];
    delete lArray[1];
    delete lArray[2];
    delete lArray[3];
    delete lArray[4];
    delete lArray[5];
    delete lArray[6];
    delete lArray[7];
    delete lArray[8];
    delete lArray[9];
    delete cEnemy;
    delete aEnemy;
    delete pEnemy;
    delete gEnemy;

    return 0;
}
