#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "entity.h"
#include "giant.h"
#include "archer.h"
#include "wizard.h"
#include "swordsman.h"

using namespace std;

class Player{
private:
    std::string username;
    char playerSel;

    Giant giant;
    Swordsman swordsman;
    Wizard wizard;
    Archer archer;
    Entity mrNobody;

    int syringes = 5;
public:
    void setUsername();
    std::string getUsername();

    Giant getGiant();
    Swordsman getSwordsman();
    Wizard getWizard();
    Archer getArcher();
    Entity getEntity();

    void receiveSyringe();
    int getSyringes();

    char getPlayerSel();

    void selectCharacter();

    void playerMovement(char c, bool Is_Battle, int &x, int &y, int useA, int &usehealth, int usR, int hComp, int &enh, int enA, int enR, int keyX, int keyY, bool IsenA, bool IsenD, bool IsuserD);
};

#endif // PLAYER_H
