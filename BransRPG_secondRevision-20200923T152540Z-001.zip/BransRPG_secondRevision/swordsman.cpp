#include <iostream>
#include "swordsman.h"

using namespace std;

Swordsman::Swordsman(){
    setName("");
    setUsername("");
    setHealth(0);
    setAttack(0);
    setRange(0);
    setAgility(0);
}
Swordsman::Swordsman(std::string user){
    setName("Swordsman");
    setUsername(user);
    setHealth(100);
    setAttack(60);
    setRange(2);
    setAgility(30);
    chosenCharacter();
}

Swordsman::~Swordsman(){

}

void Swordsman::chosenCharacter(){
    cout << "You have chosen Swordsman as your key finder!" << endl;
}
