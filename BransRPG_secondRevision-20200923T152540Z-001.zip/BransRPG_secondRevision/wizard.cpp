#include <iostream>
#include "wizard.h"

using namespace std;

Wizard::Wizard(){
    setName("");
    setUsername("");
    setHealth(0);
    setAttack(0);
    setRange(0);
    setAgility(0);
}
Wizard::Wizard(std::string user){
    setName("Wizard");
    setUsername(user);
    setHealth(50);
    setAttack(100);
    setRange(3);
    setAgility(50);
    chosenCharacter();
}

Wizard::~Wizard(){

}

void Wizard::chosenCharacter(){
    cout << "You have chosen Wizard as your key finder!" << endl;
}
