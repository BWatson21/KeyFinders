#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <iostream>
#include <vector>

using namespace std;

int xRandVal(int previousX, int keyX);

int yRandVal(int previousY, int keyY, int X);

void EnemyXYPos(int &x, int &y, int keyX, int keyY);
void EnemyXYPos(int &x, int &y, vector<int> &vectX, vector<int> &vectY, int keyX, int keyY);

bool EnemyAttack(int enAgility, bool enDefend);
bool EnemyDefend(int enAgility);

bool UserDefend(int userAgility);

#endif // ALGORITHMS_H
