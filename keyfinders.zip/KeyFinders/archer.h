#ifndef ARCHER_H
#define ARCHER_H

#include <iostream>
#include "entity.h"
using namespace std;

class Archer: public Entity{
private:

public:
    Archer();
    Archer(std::string user);
    ~Archer();

    void chosenCharacter();
};

#endif // ARCHER_H
