#include <iostream>
#include "arsonist.h"

using namespace std;

Arsonist::Arsonist(){
    setName("Arsonist");
    setHealth(50);
    setAttack(70);
    setRange(4);
    setAgility(30);
}

Arsonist::~Arsonist(){

}
