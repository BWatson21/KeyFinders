#include <iostream>
#include "cyclops.h"

using namespace std;

Cyclops::Cyclops(){
    setName("Cyclops");
    setHealth(300);
    setAttack(100);
    setRange(1);
    setAgility(10);
}

Cyclops::~Cyclops(){

}
