#ifndef CYCLOPS_H
#define CYCLOPS_H

#include <iostream>
#include "entity.h"
using namespace std;

class Cyclops: public Entity{
private:

public:
    Cyclops();
    ~Cyclops();
};

#endif // CYCLOPS_H
