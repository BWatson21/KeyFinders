#include <iostream>
#include "enemy.h"

using namespace std;

Enemy::Enemy(){}

void Enemy::setNameEnemy(string nam){
    nameEnemy = nam;
}
std::string Enemy::getNameEnemy(){
    return nameEnemy;
}

void Enemy::setHealthEnemy(int h){
    health = h;
}
int Enemy::getHealthEnemy(){
    return health;
}

void Enemy::setAttackEnemy(int att){
    attack = att;
}
int Enemy::getAttackEnemy(){
    return attack;
}

void Enemy::setRangeEnemy(int r){
    range = r;
}
int Enemy::getRangeEnemy(){
    return range;
}

void Enemy::setAgilityEnemy(int agi){
    agility = agi;
}
int Enemy::getAgilityEnemy(){
    return agility;
}

void Enemy::setPosXEnemy(int x){
    posX = x;
}
int Enemy::getPosXEnemy(){
    return posX;
}

void Enemy::setPosYEnemy(int y){
    posY = y;
}
int Enemy::getPosYEnemy(){
    return posY;
}
