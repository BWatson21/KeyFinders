#ifndef ENTITY_H
#define ENTITY_H

#include <iostream>
using namespace std;

class Entity
{
private:
    string name;
    string username;
    int health;
    int attack;
    int range;
    int agility;
    int posX = 10;
    int posY = 10;
public:
    Entity();
    Entity(std::string user);
    Entity(std::string entNam, std::string user, int h, int att, int r, int agi);

    virtual ~Entity();

    void setName(std::string nam);
    std::string getName();

    void setUsername(std::string user);
    std::string getUsername();

    void setHealth(int h);
    int getHealth();

    void setAttack(int att);
    int getAttack();

    void setRange(int r);
    int getRange();

    void setAgility(int agi);
    int getAgility();

    void setPosX(int x);
    int getPosX();

    void setPosY(int y);
    int getPosY();

    virtual void chosenCharacter();

};

#endif // ENTITY_H
