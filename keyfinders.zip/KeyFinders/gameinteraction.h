#ifndef GAMEINTERACTION_H
#define GAMEINTERACTION_H

#include <iostream>

using namespace std;

void playerControls();

void showEnemyFacts(int h, int a, int r, int ag);

void clear();
void pressX();

void dungeonIntro();
void showPlayerScore(int score);

#endif // GAMEINTERACTION_H
