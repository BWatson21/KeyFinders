#include <iostream>
#include "grid.h"

using namespace std;

void Grid::setIs_Key(bool key){
    Is_Key = key;
}
bool Grid::getIs_Key(){
    return Is_Key;
}

void Grid::setIs_Player(bool player){
    Is_Player = player;
}
bool Grid::getIs_Player(){
    return Is_Player;
}

void Grid::setIs_Enemy(bool enemy){
    Is_Enemy = enemy;
}
bool Grid::getIs_Enemy(){
    return Is_Enemy;
}

void Grid::setiVal(int i){
    iValEnemy = i;
}
int Grid::getiVal(){
    return iValEnemy;
}

void Grid::setGridX(int x){
    gridX = x;
}
int Grid::getGridX(){
    return gridX;
}

void Grid::setGridY(int y){
    gridY = y;
}
int Grid::getGridY(){
    return gridY;
}
