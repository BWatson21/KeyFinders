#ifndef GRID_H
#define GRID_H

#include <iostream>

using namespace std;

class Grid{
private:
    bool Is_Key = false;
    bool Is_Player = false;
    bool Is_Enemy = false;
    int iValEnemy;
    int gridX;
    int gridY;
public:
    void setIs_Key(bool);
    bool getIs_Key();

    void setIs_Player(bool);
    bool getIs_Player();

    void setIs_Enemy(bool);
    bool getIs_Enemy();

    void setiVal(int);
    int getiVal();

    void setGridX(int);
    int getGridX();

    void setGridY(int);
    int getGridY();
};

#endif // GRID_H
