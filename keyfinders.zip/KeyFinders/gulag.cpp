#include <iostream>
#include "gulag.h"

using namespace std;

Gulag::Gulag(){
    setName("Gulag");
    setHealth(30);
    setAttack(5);
    setRange(1);
    setAgility(20);
}

Gulag::~Gulag(){

}
