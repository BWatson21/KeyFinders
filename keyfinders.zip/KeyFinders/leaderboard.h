#ifndef LEADERBOARD_H
#define LEADERBOARD_H

#include <iostream>

using namespace std;

class Leaderboard
{
private:
    std::string player;
    long int score;
public:
    void setPlayer(std::string p);
    std::string getPlayer();

    void setScore(long int s);
    long int getScore();
};

#endif // LEADERBOARD_H
