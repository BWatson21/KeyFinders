#include <iostream>
#include "player.h"
#include "grid.h"
#include "gameinteraction.h"

using namespace std;

void Player::setUsername(){
    cout << "Enter a name in which you would like to be called: ";
    string user;
    cin >> user;
    username = user;

    clear();
}
std::string Player::getUsername(){
    return username;
}

Giant Player::getGiant(){
    return giant;
}
Swordsman Player::getSwordsman(){
    return swordsman;
}
Wizard Player::getWizard(){
    return wizard;
}
Archer Player::getArcher(){
    return archer;
}
Entity Player::getEntity(){
    return mrNobody;
}

void Player::receiveSyringe(){
    syringes++;
}
int Player::getSyringes(){
    return syringes;
}


char Player::getPlayerSel(){
    return playerSel;
}

void Player::selectCharacter(){
    //username prompt
    string username;
    username = getUsername();

    //select character prompt
    cout << "Hello " << username << "!" << endl;
    cout << "Now that you have a name, choose your keyfinder. Choose wisely..." << endl;
    cout << "-----------------------------------------------------------------" << endl;
    cout << "1 - Giant" << endl;
    cout << "2 - Swordsman" << endl;
    cout << "3 - Wizard" << endl;
    cout << "4 - Archer" << endl;
    cout << "-----------------------------------------------------------------" << endl;
    for (int i = 0; i < 10; i++){
        cout << "\n";
    }
    cout << "Selection: ";

    char selection;
    cin >> selection;

    clear();

    //case selection
    switch (selection){
    case '1': //player chooses giant
    {
        playerSel = '1';
        Giant g(username);
        giant = g;
        cout << "------------Keyfinder Stats-----------" << endl;
        cout << "Your keyfinder's Name: " << giant.getUsername() << endl;
        cout << "Your keyfinder's Health: " << giant.getHealth() << endl;
        cout << "Your keyfinder's Damage: " << giant.getAttack() << endl;
        cout << "Your keyfinder's Range: " << giant.getRange() << endl;
        cout << "Your keyfinder's Speed: " << giant.getAgility() << endl;
        cout << "--------------------------------------" << endl;
        for (int i = 0; i < 10; i++){
            cout << "\n";
        }
        break;
    }
    case '2': //player chooses swordsman
    {
        playerSel = '2';
        Swordsman s(username);
        swordsman = s;
        cout << "------------Keyfinder Stats-----------" << endl;
        cout << "Your keyfinder's Name: " << swordsman.getUsername() << endl;
        cout << "Your keyfinder's Health: " << swordsman.getHealth() << endl;
        cout << "Your keyfinder's Damage: " << swordsman.getAttack() << endl;
        cout << "Your keyfinder's Range: " << swordsman.getRange() << endl;
        cout << "Your keyfinder's Speed: " << swordsman.getAgility() << endl;
        cout << "--------------------------------------" << endl;
        for (int i = 0; i < 10; i++){
            cout << "\n";
        }
        break;
    }
    case '3': //player chooses wizard
    {
        playerSel = '3';
        Wizard w(username);
        wizard = w;
        cout << "------------Keyfinder Stats-----------" << endl;
        cout << "Your keyfinder's Name: " << wizard.getUsername() << endl;
        cout << "Your keyfinder's Health: " << wizard.getHealth() << endl;
        cout << "Your keyfinder's Damage: " << wizard.getAttack() << endl;
        cout << "Your keyfinder's Range: " << wizard.getRange() << endl;
        cout << "Your keyfinder's Speed: " << wizard.getAgility() << endl;
        cout << "--------------------------------------" << endl;
        for (int i = 0; i < 10; i++){
            cout << "\n";
        }
        break;
    }
    case '4': //player chooses archer
    {
        playerSel = '4';
        Archer a(username);
        archer = a;
        cout << "------------Keyfinder Stats-----------" << endl;
        cout << "Your keyfinder's Name: " << archer.getUsername() << endl;
        cout << "Your keyfinder's Health: " << archer.getHealth() << endl;
        cout << "Your keyfinder's Damage: " << archer.getAttack() << endl;
        cout << "Your keyfinder's Range: " << archer.getRange() << endl;
        cout << "Your keyfinder's Speed: " << archer.getAgility() << endl;
        cout << "--------------------------------------" << endl;
        for (int i = 0; i < 10; i++){
            cout << "\n";
        }
        break;
    }
    case 'k': //player chooses hidden character mr.nobody
    {
        playerSel = 'k';
        cout << "You have found a hidden character!" << endl;
        Entity mr(username);
        mrNobody = mr;
        cout << "------------Keyfinder Stats-----------" << endl;
        cout << "Your keyfinder's Name: " << mrNobody.getUsername() << endl;
        cout << "Your keyfinder's Health: " << mrNobody.getHealth() << endl;
        cout << "Your keyfinder's Damage: " << mrNobody.getAttack() << endl;
        cout << "Your keyfinder's Range: " << mrNobody.getRange() << endl;
        cout << "Your keyfinder's Speed: " << mrNobody.getAgility() << endl;
        cout << "--------------------------------------" << endl;
        for (int i = 0; i < 10; i++){
            cout << "\n";
        }
        break;
    }
    default:
        playerSel = '0';
        cout << "Invalid Selection." << endl;
        selectCharacter();
        break;
    }

    pressX();
}

void Player::playerMovement(char c, bool Is_Battle, int &x, int &y, int useA, int &usehealth, int usR, int hComp, int &enh, int enA, int enR, int keyX, int keyY, bool IsenA, bool IsenD, bool IsuserD){
    if (Is_Battle == false){
        switch(c){
        case 'D': //move forward
        case 'd':
            if (x < 19){
                x++;
            }
            else if (x == 19){
                cout << "You've reached the edge of the dungeon." << endl;
                x = 19;
            }
            break;
        case 'S': //move left
        case 's':
            if (y > 0){
                if (y == 1){
                    y = 0;
                }
                else{
                    y--;
                }
            }
            else if (y == 0){
                cout << "You've reached the edge of the dungeon." << endl;
                y = 0;
            }

            break;
        case 'A': //move backward
        case 'a':
            if (x > 0){
                if (x == 1){
                    x = 0;
                }
                else{
                    x--;
                }
            }
            else if (x == 0){
                cout << "You've reached the edge of the dungeon." << endl;
                x = 0;
            }
            break;
        case 'W': //move right
        case 'w':
            if (y < 19){
                y++;
            }
            else if (y == 19){
                cout << "You've reached the edge of the dungeon." << endl;
                y = 19;
            }
            break;
        case 'E': //use syringes (outside of battle)
        case 'e':
            if (usehealth == hComp){
                cout << "Your health is full." << endl;
            }
            else if (usehealth < hComp){
                cout << "You have used a syringe" << endl;
                cout << "Your health has been restored to full capacity." << endl;
                syringes--;
                usehealth = hComp;
            }
            break;
        case '8':
        case '*':
            cout << "You must know the secret passcode." << endl;
            cout << "The key is at: " << keyX << ", " << keyY << endl;
            break;
        default:
            cout << "Whilst not in battle, you may only move or use syringes." << endl;
            break;
        }
    }
    else if (Is_Battle == true){
        switch(c){
        case 'E': //use syringes (inside of battle)
        case 'e':
            if (usehealth == hComp){
                cout << "Your health is full." << endl;
            }
            else if (usehealth < hComp){
                cout << "You have used a syringe" << endl;
                cout << "Your health has been restored to full capacity." << endl;
                syringes--;
                usehealth = hComp;
            }
            break;
        case 'R': //player attack
        case 'r':
            cout << "You have attacked" << endl;
            if (IsenD == true){
                cout << "The enemy has paried your attack." << endl;
            }
            else if (IsenD == false){
                cout << "The enemy has got gotted!" << endl;
                enh -= (useA / usR);
            }
            break;
        case 'C': //player defend
        case 'c':
            cout << "You have defended" << endl;
            if ((IsuserD == true) && (IsenA == false)){
                cout << "You have defended, however your foe did not attack." << endl;
            }
            else if ((IsuserD == true) && (IsenA == true)){
                cout << "You have paried your enemies attack." << endl;
            }
            else if ((IsuserD == false) && (IsenA == false)){

            }
            else if ((IsuserD == false) && (IsenA == true)){
                cout << "You have got gotted!" << endl;
                usehealth -= (enA / enR);
            }
            break;
        default:
            cout << "The only taks you can perform in battle are: using syringes, attacking, defending" << endl;
            break;
        }
    }
}
