#include <iostream>
#include "psychomaniac.h"

using namespace std;

Psychomaniac::Psychomaniac(){
    setName("Psychomaniac");
    setHealth(80);
    setAttack(60);
    setRange(2);
    setAgility(50);
}

Psychomaniac::~Psychomaniac(){

}
