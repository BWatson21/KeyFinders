#ifndef PSYCHOMANIAC_H
#define PSYCHOMANIAC_H

#include <iostream>
#include "entity.h"

using namespace std;

class Psychomaniac: public Entity{
private:

public:
    Psychomaniac();
    ~Psychomaniac();
};

#endif // PSYCHOMANIAC_H
