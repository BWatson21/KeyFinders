#ifndef SWORDSMAN_H
#define SWORDSMAN_H

#include <iostream>
#include "entity.h"
using namespace std;

class Swordsman: public Entity{
private:

public:
    Swordsman();
    Swordsman(std::string user);
    ~Swordsman();

    void chosenCharacter();
};

#endif // SWORDSMAN_H
