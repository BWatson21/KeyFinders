#ifndef WIZARD_H
#define WIZARD_H

#include <iostream>
#include "entity.h"
using namespace std;

class Wizard: public Entity{
private:

public:
    Wizard();
    Wizard(std::string user);
    ~Wizard();

    void chosenCharacter();
};

#endif // WIZARD_H
